---
name: Noteflow Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464555'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#6b38d4'
  on-secondary: '#ffffff'
  secondary-container: '#8455ef'
  on-secondary-container: '#fffbff'
  tertiary: '#005338'
  on-tertiary: '#ffffff'
  tertiary-container: '#006e4b'
  on-tertiary-container: '#67f4b7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Inter
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 4.25rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  title-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.0625rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: '0'
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: -0.005em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.01em
  code:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: '0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system embodies the ethos of a high-performance, distraction-free digital workspace. Built for knowledge workers, developers, and thinkers, it blends the editorial precision of Craft, the keyboard-driven immediacy of Linear, and the composable flexibility of Notion.

### Visual Character & Identity
- **Minimalist Precision:** Content takes absolute precedence. UI chrome retreats into the background until intentionally summoned, using sub-pixel borders and whisper-soft background shifts instead of heavy surface divides.
- **Atmospheric Clarity:** Subtle translucent overlays and backdrop blurs (`backdrop-blur-md`) deliver depth during modal interactions and context switching without visual clutter.
- **Tactile Utility:** Micro-interactions feel snappy and physical, anchored by sub-150ms transitions, subtle scale shifts on press (`active:scale-[0.98]`), and precise focus indicators.
- **Korean Localization Nuance:** Designed with tight vertical metrics, generous tracking adjustments, and word-break rules (`word-break: keep-all`) tailored specifically for Korean typography, preventing awkward sentence ragging and broken compound phrases.

## Colors

The palette balances clinical functional neutrals with an expressive, focused accent system. The workspace canvas uses calibrated slate tones that reduce eye fatigue during multi-hour writing and planning sessions.

### Functional Roles
- **Canvas Base (`#F8FAFC`):** The ambient workbench background.
- **Surface Elevation 0 (`#FFFFFF`):** Note pages, workspace cards, and active focus panels.
- **Surface Secondary (`#F1F5F9`):** Sidebar panels, toolbar clusters, and nested blocks.
- **Borders & Dividers (`#E2E8F0` / `rgba(226, 232, 240, 0.8)`): Subtle structural demarcations.
- **Primary Ink (`#0F172A`):** Core typography, headers, and high-emphasis icons.
- **Muted Ink (`#64748B`):** Metadata, timestamps, breadcrumbs, and placeholder indicators.
- **Accent Indigo (`#4F46E5`):** Active selections, primary CTA actions, text caret, and linked references.
- **Status & Semantics:**
  - **Violet (`#8B5CF6`):** AI intelligence tools, inline completions, and semantic search queries.
  - **Emerald (`#10B981`):** Real-time sync confirmations, active collaborators, and publication states.
  - **Rose (`#F43F5E`):** Destructive actions, system alerts, and archive warnings.

## Typography

The typography stack uses Inter paired with system sans fallbacks (`Pretendard`, `-apple-system`, `BlinkMacSystemFont`) to ensure crisp rendering on Korean glyphs alongside Latin typography.

### Structural Rules
- **Line Length & Column Rhythm:** Prose containers strictly maintain a maximum width of `68ch` to ensure optimal reading ergonomics.
- **Korean Reading Dynamics:** All prose and block elements apply `word-break: keep-all` and `overflow-wrap: break-word` to maintain structural word integrity.
- **Code & Syntax:** Inline code fragments and block editors employ `JetBrains Mono` at a calibrated 85% scale relative to surrounding text, maintaining an even baseline.

## Layout & Spacing

The layout model adapts between a three-column productivity shell and a distraction-free single-canvas editor.

### Structural Layout Model
- **Collapsible Sidebar (Navigation):** Fixed `240px` (or `280px` expanded), collapsible to `0px` on mobile or under a focus hotkey (`Cmd/Ctrl + \`).
- **Secondary Index Pane (Note Stream):** Dynamic width between `280px` and `340px` for search streams and workspace navigation.
- **Editor Canvas:** Fluid center-anchored surface (`max-w-[840px]`) centered within the remaining viewport.
- **Breakpoints:**
  - **Mobile (`< 768px`):** Stacked full-width views. Navigation transitions into an edge-swipe sheet drawer. Gutter set to `0.75rem`, margins to `1rem`.
  - **Tablet (`768px - 1023px`):** Dual-pane structure. Canvas and sidebar toggleable via header iconography.
  - **Desktop (`>= 1024px`):** Tri-pane layout active by default with continuous content sync.

## Elevation & Depth

Visual hierarchy uses physical layer stacking combined with hairline translucent borders instead of heavy drop shadows.

### Elevation Hierarchy
- **Level 0 (Flat Canvas):** `#F8FAFC` background without elevation or border.
- **Level 1 (Panels & Sidebar):** `#FFFFFF` with a right or perimeter border of `1px solid rgba(226, 232, 240, 0.85)`. No drop shadow.
- **Level 2 (Interactive Floating Bars & Popovers):** `#FFFFFF` with `box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.06), 0 2px 6px -1px rgba(15, 23, 42, 0.03)` and a sub-pixel border `1px solid rgba(226, 232, 240, 0.6)`.
- **Level 3 (Modal Overlays & Quick Switcher):** Backdrop filled with `rgba(15, 23, 42, 0.35)` with `backdrop-filter: blur(8px)`. The surface uses `box-shadow: 0 24px 48px -12px rgba(15, 23, 42, 0.18)` and an inner highlight rim of `inset 0 1px 0 0 rgba(255, 255, 255, 0.8)`.
- **Floating Text Selection Bar:** `rgba(15, 23, 42, 0.92)` dark glass surface with `backdrop-filter: blur(12px)`, crisp white micro-icons, and an inner border `1px solid rgba(255, 255, 255, 0.12)`.

## Shapes

The interface balances soft modern curves with geometric efficiency, providing approachable comfort without losing valuable screen estate.

### Geometry Hierarchy
- **Base Geometry (`rounded-md`, 6px):** Compact elements such as dropdown options, checkboxes, inline tags, keyboard shortcuts (`kbd`), and contextual action triggers.
- **Intermediate Geometry (`rounded-lg`, 8px):** Primary form controls, text inputs, list-item hover targets, and toolbar action clusters.
- **Macro Geometry (`rounded-xl` to `rounded-2xl`, 12px - 16px):** Floating tool palettes, note page cards, modal dialogues, and preview containers.
- **Pill Targets (`rounded-full`):** Collaborator avatars, status indicator dots, and interactive active filter chips.